# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

from __future__ import annotations

import socket
import threading
from typing import Dict, Optional

from .log import get_logger
from .subs import SubscriptionDispatcher


class _FramedMessage:
    """
    Represents the full message from/to EAS.
    Attributes:
        seq: sequence number
        payload: contains the API wire header and the response data
    """

    FRAME_SIZE = 6
    API_HEADER_SIZE = 20
    MAGIC = b"\xaa\xbb"

    def __init__(self, seq: int, payload: bytes, payload_len: Optional[int] = None):
        """
        Initialize a message with EAS protocol.
        Args:
            seq: sequence number
            payload: contains the API wire header and the response data
            payload_len: length of the payload, if it's None, it will be calculated
        Raises:
            ValueError: if the given parameters are not valid
        """
        if not 0 <= seq <= 65535:
            raise ValueError(f'The given sequence number ({seq}) is invalid, should be between 0 and 65535')
        self.seq = seq
        if payload_len is not None and payload_len != len(payload):
            raise ValueError(
                f'The given payload length ({payload_len}) is not equal '
                f'with the length of the given payload ({len(payload)})'
            )
        self.payload = payload

    def __bytes__(self) -> bytes:
        """
        Serialize the message to bytes
        Returns:
            The serialized message as bytes
        """
        return b''.join([self.MAGIC, self.seq.to_bytes(2, 'big'), len(self.payload).to_bytes(2, 'big'), self.payload])

    def __len__(self) -> int:
        return self.FRAME_SIZE + len(self.payload)

    @classmethod
    def parse_first(cls, framed_payload: bytes) -> _FramedMessage:
        """
        Parse the first message from the given bytes.
        Args:
            framed_payload: bytes to parse
        Returns:
            First parsed message, and the number of parsed bytes
        Raises:
            ValueError: if the message is not valid
        """
        if len(framed_payload) < cls.FRAME_SIZE:
            raise ValueError('Message is smaller than the frame size (6 bytes).')
        magic = framed_payload[:2]
        if magic != cls.MAGIC:
            raise ValueError('The parsed payload first 2 bytes are not valid')
        seq = int.from_bytes(framed_payload[2:4], 'big')
        payload_len = int.from_bytes(framed_payload[4 : cls.FRAME_SIZE], 'big')
        payload = framed_payload[cls.FRAME_SIZE : cls.FRAME_SIZE + payload_len]
        return cls(seq=seq, payload_len=payload_len, payload=payload)

    def is_response_or_request(self) -> bool:
        """
        Check if the message is a response or a request,
        but not a heartbeat response or a notification.
        Returns:
            True if the message is a response or request, otherwise False
        """
        return 0 < self.seq <= 65535 and len(self) >= self.API_HEADER_SIZE + self.FRAME_SIZE

    def is_notification(self) -> bool:
        """
        Check if the message is a notification.
        Returns:
            True if the message is a notification, otherwise False
        """
        return self.seq == 0 and len(self) >= self.API_HEADER_SIZE + self.FRAME_SIZE


class Connection:
    """
    Class for representing a client connection to the External API Server (EAS)
    Note:
        This is a helper class for other classes to communicate with the EAS.
        Creating an instance explicitly is not recommended.
    """

    HEARTBEAT = bytes(_FramedMessage(seq=0, payload=b""))

    def __init__(
        self,
        host: str,
        port: int,
        subscription_dispatcher: SubscriptionDispatcher,
        response_timeout: float = 10.0,
    ):
        """
        Initialize the connection.

        Args:
            host: host name to connect
            port: port number for socket connection
            subscription_dispatcher: handler class for notifications
            response_timeout: response timeout in seconds
        """
        self._logger = get_logger(__name__)
        self._host = host
        self._port = port
        self._subs_dispatcher = subscription_dispatcher
        self._response_timeout = response_timeout
        self._events: Dict[int, threading.Event] = {}
        self._responses: Dict[int, bytes] = {}
        self._write_lock = threading.Lock()
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._heartbeat_timer = threading.Timer(interval=1.0, function=self._send_heartbeat)
        self._recv_thread = threading.Thread(target=self._receive)
        self._disconnect = threading.Event()
        self._seq_num = 1

    def connect(self) -> None:
        """
        Connects to the host given in the constructor parameters.
        Starts the heartbeat and the receive thread.
        """
        self._socket.connect((self._host, self._port))
        self._heartbeat_timer.start()
        self._recv_thread.start()
        self._logger.info('Connected to EAS')

    def disconnect(self) -> None:
        """
        Stops threads and close the connection.
        """
        self._disconnect.set()
        self._heartbeat_timer.cancel()
        self._recv_thread.join()
        self._socket.close()
        self._logger.info('Disconnected from EAS')

    def send_request(self, request: bytes) -> bytes:
        """
        Sends the given request to the External API Server.
        Args:
            request: the request bytes to send without the frame

        Returns:
            the received response in a bytearray
        """
        seq = self._next_seq()
        event = threading.Event()
        self._events[seq] = event
        framed_request = bytes(_FramedMessage(seq=seq, payload=request))
        with self._write_lock:
            size = self._socket.send(framed_request)
        self._logger.debug('Sent out %d bytes, sequence number: %d', size, seq)
        if not event.wait(timeout=self._response_timeout):
            raise TimeoutError(f'Response timed out after {self._response_timeout}s with sequence number: {seq}')
        return self._responses[seq]

    def _send_heartbeat(self) -> None:
        with self._write_lock:
            self._socket.send(self.HEARTBEAT)
        self._heartbeat_timer = threading.Timer(interval=1.0, function=self._send_heartbeat)
        self._heartbeat_timer.start()

    def _receive(self) -> None:
        while not self._disconnect.is_set():
            data = self._socket.recv(4096)
            offset = 0
            while len(data) > offset:
                try:
                    response = _FramedMessage.parse_first(data[offset:])
                except ValueError as error:
                    self._logger.error(error)
                    break
                offset += len(response)
                if response.is_response_or_request():
                    self._logger.debug('Response received with sequence number: %d', response.seq)
                    self._responses[response.seq] = response.payload
                    self._events[response.seq].set()
                if response.is_notification():
                    self._logger.debug('Notification received')
                    try:
                        self._subs_dispatcher.handle(response.payload)
                    except ValueError as error:
                        self._logger.error(error)

    def _next_seq(self) -> int:
        actual_seq = self._seq_num
        self._seq_num += 1
        if self._seq_num > 65535:
            self._seq_num = 1
        return actual_seq
