# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

"""
Wrapper module for python standard logging library
Note:
    The configure functions set global state, that
    will be used to create a logger with get_logger().
"""

import logging
from typing import Callable, List

DEFAULT_LEVEL = logging.WARNING
DEFAULT_FORMAT = '%(asctime)s (%(levelname)s) [%(filename)s:%(lineno)d - %(funcName)s] %(message)s'


setup_funcs: List[Callable[[logging.Logger], None]] = []


def _create_log_level_setup(level: int) -> None:
    def setup_log_level(logger: logging.Logger) -> None:
        logger.setLevel(level)

    setup_funcs.append(setup_log_level)


def _create_log_format_setup(fmt: str) -> None:
    def setup_log_format(logger: logging.Logger) -> None:
        for handler in logger.handlers:
            handler.setFormatter(logging.Formatter(fmt))

    setup_funcs.append(setup_log_format)


def _create_stream_handler_setup() -> None:
    def setup_stream_handler(logger: logging.Logger) -> None:
        logger.addHandler(logging.StreamHandler())

    setup_funcs.append(setup_stream_handler)


def configure_logger(level: int = None, format_str: str = None) -> None:
    """
    Configure the logger.
    Note:
        This will setup a state, when a logger will be created,
        this config will be used.
    Args:
        level: level of the logging module
        format_str: the format of the log messages
    """
    _create_log_level_setup(level or DEFAULT_LEVEL)
    _create_stream_handler_setup()
    _create_log_format_setup(format_str or DEFAULT_FORMAT)


def get_logger(name: str) -> logging.Logger:
    """
    Create a logger with the given name, and with the given configuration
    Args:
        name: the name of the logger object

    Returns:
        The created logger, with the given configuration
    """
    logger = logging.getLogger(name)
    if not logger.hasHandlers():
        for setup_func in setup_funcs:
            setup_func(logger)
    return logging.getLogger(name)
