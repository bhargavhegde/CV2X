# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

from dataclasses import dataclass
from enum import IntEnum, auto

from pycmssdk.typing import DefaultEnumMeta

ServiceGroup = int

SubsDataKey = int
"""Subscription data key, used as a filtering value
"""


class SubscriptionCommand(IntEnum, metaclass=DefaultEnumMeta):
    """
    Subscription event type.
    Note:
        Not to be used manually.

    """

    SUBSCRIBE = 0
    UNSUBSCRIBE = auto()


@dataclass
class SubscriptionData:
    """
    Data structure for subscription events.
    Note:
        Not to be used manually.

    """

    command: SubscriptionCommand = SubscriptionCommand()  # type: ignore[call-arg]
    key: SubsDataKey = SubsDataKey()
    group: ServiceGroup = ServiceGroup()


@dataclass
class SubsNotifHandle:
    """
    Meta info for subscription notification.
    To be included in the data struct of the notification service.

    """

    key: SubsDataKey = SubsDataKey()
