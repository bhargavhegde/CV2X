# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

from __future__ import annotations

import ctypes

from pycmssdk.typedef.subs_types import (
    ServiceGroup,
    SubscriptionCommand,
    SubscriptionData,
    SubsDataKey,
    SubsNotifHandle,
)
from pycmssdk.typing import Codec


class _ServiceGroup(ctypes.c_uint32, Codec[ServiceGroup]):  # pylint: disable=too-many-ancestors
    def encode(self) -> ServiceGroup:
        return self.value

    @staticmethod
    def decode(data: ServiceGroup) -> _ServiceGroup:
        return _ServiceGroup(data)


class _SubsDataKey(ctypes.c_uint64, Codec[SubsDataKey]):  # pylint: disable=too-many-ancestors
    def encode(self) -> SubsDataKey:
        return self.value

    @staticmethod
    def decode(data: SubsDataKey) -> _SubsDataKey:
        return _SubsDataKey(data)


class _SubscriptionCommand(ctypes.c_int, Codec[SubscriptionCommand]):  # pylint: disable=too-many-ancestors
    def encode(self) -> SubscriptionCommand:
        return SubscriptionCommand(self.value)

    @staticmethod
    def decode(data: SubscriptionCommand) -> _SubscriptionCommand:
        return _SubscriptionCommand(data.value)


class _SubscriptionData(ctypes.Structure, Codec[SubscriptionData]):  # pylint: disable=too-many-ancestors

    _fields_ = [
        ('command', _SubscriptionCommand),
        ('key', _SubsDataKey),
        ('group', _ServiceGroup),
    ]

    def encode(self) -> SubscriptionData:
        return SubscriptionData(
            command=self.command.encode(),
            key=self.key.encode(),
            group=self.group.encode(),
        )

    @staticmethod
    def decode(data: SubscriptionData) -> _SubscriptionData:
        return _SubscriptionData(
            command=_SubscriptionCommand.decode(data.command),
            key=_SubsDataKey.decode(data.key),
            group=_ServiceGroup.decode(data.group),
        )

    _pack_ = 1


class _SubsNotifHandle(ctypes.Structure, Codec[SubsNotifHandle]):  # pylint: disable=too-many-ancestors

    _fields_ = [
        ('key', _SubsDataKey),
    ]

    def encode(self) -> SubsNotifHandle:
        return SubsNotifHandle(
            key=self.key.encode(),
        )

    @staticmethod
    def decode(data: SubsNotifHandle) -> _SubsNotifHandle:
        return _SubsNotifHandle(
            key=_SubsDataKey.decode(data.key),
        )

    _pack_ = 1
