# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

import threading
from enum import Enum, auto
from typing import Any, Dict, cast

from pycrate_asn1rt import asnobj  # type: ignore[import]
from pycrate_core.utils import PycrateErr  # type: ignore[import]

from .asn1types import asn1_cn, asn1_eu, asn1_us


class Asn1Type(Enum):
    """Enum that represents the supported ASN.1 top level encode/decode"""

    # US
    US_MESSAGE_FRAME = auto()
    US_WSA = auto()
    # EU
    EU_CAM = auto()
    EU_DENM = auto()
    EU_DECENTRALIZED_ENVIRONMENT_NOTIFICATION = auto()
    EU_MAP = auto()
    EU_SPAT = auto()
    EU_IVI = auto()
    EU_RTCM = auto()
    EU_SRM = auto()
    EU_SSM = auto()
    EU_CPM = auto()
    # CN
    CN_MESSAGE_FRAME = auto()


class Asn1EncodeFailed(Exception):
    """ASN.1 encoding failure"""

    def __init__(self, asn_type: Asn1Type, payload: Dict[str, Any]):
        super().__init__(f'{asn_type.name} cannot encode {payload}')
        self.asn_type = asn_type
        self.payload = payload


class Asn1DecodeFailed(Exception):
    """ASN.1 decoding failure"""

    def __init__(self, asn_type: Asn1Type, payload: bytes):
        super().__init__(f'{asn_type.name} cannot decode {payload.hex()}')
        self.asn_type = asn_type
        self.payload = payload


class Asn1Codec:
    def __init__(self, codec: asnobj.ASN1Obj):
        self.codec = codec
        self.codec_lock = threading.Lock()

    def encode(self, asn1_obj: Dict[str, Any]) -> bytes:
        assert self.codec_lock is not None
        assert self.codec is not None

        with self.codec_lock:
            return cast(bytes, self.codec.to_uper(asn1_obj))

    def decode(self, payload: bytes) -> Dict[str, Any]:
        assert self.codec_lock is not None
        assert self.codec is not None
        with self.codec_lock:
            self.codec.from_uper(payload)
            return cast(Dict[str, Any], self.codec())


# US
USMessageFrameCodec = Asn1Codec(asn1_us.MessageFrame.MessageFrame)
WSACodec = Asn1Codec(asn1_us.Ieee1609Dot3Wsa.SrvAdvMsg)
# EU
CAMCodec = Asn1Codec(asn1_eu.CAM_PDU_Descriptions.CAM)
DENMCodec = Asn1Codec(asn1_eu.DENM_PDU_Descriptions.DENM)
DENMNoPduCodec = Asn1Codec(asn1_eu.DENM_PDU_Descriptions.DecentralizedEnvironmentalNotificationMessage)
MAPCodec = Asn1Codec(asn1_eu.MAP_SPAT_CEN.MAP)
SPATCodec = Asn1Codec(asn1_eu.MAP_SPAT_CEN.SPAT)
IVICodec = Asn1Codec(asn1_eu.IVI_Data.IVI)
RTCMCodec = Asn1Codec(asn1_eu.MAP_SPAT_CEN.SPAT)
SRMCodec = Asn1Codec(asn1_eu.MAP_SPAT_CEN.SRM)
SSMCodec = Asn1Codec(asn1_eu.MAP_SPAT_CEN.SSM)
CPMCodec = Asn1Codec(asn1_eu.CPM_PDU_Descriptions.CPM)
# CN
CNMessageFrameCodec = Asn1Codec(asn1_cn.MsgFrame.MessageFrame)


def asn1_encode(asn1_dict: Dict[str, Any], payload_type: Asn1Type) -> bytes:
    """
    UPER encodes the given dictionary
    Args:
        asn1_dict: dictionary representation of the ASN.1 structure
        payload_type: the top level ASN.1 type
    Returns:
        UPER encoded bytes representation of the structure
    Raises:
        Asn1EncodeFailed: the UPER encoding failed
    """
    # pylint: disable=too-many-branches,too-many-return-statements
    try:
        if payload_type == Asn1Type.US_MESSAGE_FRAME:
            return USMessageFrameCodec.encode(asn1_dict)
        if payload_type == Asn1Type.US_WSA:
            return WSACodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_CAM:
            return CAMCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_DENM:
            return DENMCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_DECENTRALIZED_ENVIRONMENT_NOTIFICATION:
            return DENMNoPduCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_MAP:
            return MAPCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_SPAT:
            return SPATCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_IVI:
            return IVICodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_RTCM:
            return RTCMCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_SRM:
            return SRMCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_SSM:
            return SSMCodec.encode(asn1_dict)
        if payload_type == Asn1Type.EU_CPM:
            return CPMCodec.encode(asn1_dict)
        if payload_type == Asn1Type.CN_MESSAGE_FRAME:
            return CNMessageFrameCodec.encode(asn1_dict)
        raise ValueError(f'The payload type is not supported: {payload_type.name}')
    except PycrateErr as error:
        raise Asn1EncodeFailed(payload_type, asn1_dict) from error


def asn1_decode(msg: bytes, payload_type: Asn1Type) -> Dict[str, Any]:
    """
    UPER decodes the given message to a dictionary representation
    Args:
        msg: message to decode
        payload_type: the top level ASN.1 type
    Returns:
        Dictionary that represents the ASN.1 structure
    Raises:
        Asn1DecodeFailed: if the decode failed
    """
    # pylint: disable=too-many-branches,too-many-return-statements
    try:
        if payload_type == Asn1Type.US_MESSAGE_FRAME:
            return USMessageFrameCodec.decode(msg)
        if payload_type == Asn1Type.US_WSA:
            return WSACodec.decode(msg)
        if payload_type == Asn1Type.EU_CAM:
            return CAMCodec.decode(msg)
        if payload_type == Asn1Type.EU_DENM:
            return DENMCodec.decode(msg)
        if payload_type == Asn1Type.EU_DECENTRALIZED_ENVIRONMENT_NOTIFICATION:
            return DENMNoPduCodec.decode(msg)
        if payload_type == Asn1Type.EU_MAP:
            return MAPCodec.decode(msg)
        if payload_type == Asn1Type.EU_SPAT:
            return SPATCodec.decode(msg)
        if payload_type == Asn1Type.EU_IVI:
            return IVICodec.decode(msg)
        if payload_type == Asn1Type.EU_RTCM:
            return RTCMCodec.decode(msg)
        if payload_type == Asn1Type.EU_SRM:
            return SRMCodec.decode(msg)
        if payload_type == Asn1Type.EU_SSM:
            return SSMCodec.decode(msg)
        if payload_type == Asn1Type.EU_CPM:
            return CPMCodec.decode(msg)
        if payload_type == Asn1Type.CN_MESSAGE_FRAME:
            return CNMessageFrameCodec.decode(msg)
        raise ValueError(f'The payload type is not supported: {payload_type.name}')
    except PycrateErr as error:
        raise Asn1DecodeFailed(payload_type, msg) from error
