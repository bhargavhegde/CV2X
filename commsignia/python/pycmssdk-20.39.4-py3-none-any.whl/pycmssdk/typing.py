# Copyright (C) Commsignia Ltd. - All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
# Date 2021-2023

from __future__ import annotations

import ctypes
from abc import abstractmethod
from enum import EnumMeta
from typing import Any, Generic, Tuple, TypeVar

PublicT = TypeVar('PublicT')


class Codec(Generic[PublicT]):
    @abstractmethod
    def encode(self) -> PublicT:
        pass

    @staticmethod
    @abstractmethod
    def decode(data: PublicT) -> Codec[PublicT]:
        pass


class CodecStructure(ctypes.Structure, Generic[PublicT], Codec[PublicT]):
    @abstractmethod
    def encode(self) -> PublicT:
        pass

    @staticmethod
    @abstractmethod
    def decode(data: PublicT) -> Codec[PublicT]:
        pass


class DefaultEnumMeta(EnumMeta):
    default = object()

    def __call__(cls, value: Any = default, **kwargs):  # type: ignore[no-untyped-def, override]
        if value is cls.default:
            return next(iter(cls))
        return super().__call__(value, **kwargs)


T = TypeVar('T')

Tuple3 = Tuple[T, T, T]
Tuple4 = Tuple[T, T, T, T]
Tuple6 = Tuple[T, T, T, T, T, T]
Tuple8 = Tuple[T, T, T, T, T, T, T, T]
Tuple11 = Tuple[T, T, T, T, T, T, T, T, T, T, T]
Tuple12 = Tuple[T, T, T, T, T, T, T, T, T, T, T, T]
Tuple16 = Tuple[T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T]
Tuple31 = Tuple[T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T]
Tuple32 = Tuple[T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T]
Tuple33 = Tuple[T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T]
Tuple40 = Tuple[
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
]
Tuple48 = Tuple[
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
    T,
]
