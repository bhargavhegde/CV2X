# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.
import concurrent.futures

from .api import API
from .eac import Connection
from .log import configure_logger
from .subs import SubscriptionDispatcher
from .subscription_handlers import SUBSCRIPTION_HANDLERS


def create_cms_api(
    *,
    host: str,
    port: int = 7942,
    log_settings: dict = None,
    max_workers: int = 1,
) -> API:
    """
    Create an API instance with the given parameters
    Args:
        host: host to connect
        port: port number for the External API Server connection
        log_settings: dictionary for log settings, it will be forwarded
            to the python's logging module as the configuration
        max_workers: max worker number for the thread pool,
            that will handle the notification callbacks

    Returns:
        The created API instance
    """
    configure_logger(**(log_settings or {}))
    thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
    handlers = [handler(thread_pool) for handler in SUBSCRIPTION_HANDLERS]
    handler_dispatch_map = {handler.service_code: handler for handler in handlers}
    subscription_dispatcher = SubscriptionDispatcher(handler_dispatch_map)
    connection = Connection(host, port, subscription_dispatcher)
    return API(connection, subscription_dispatcher, thread_pool)
