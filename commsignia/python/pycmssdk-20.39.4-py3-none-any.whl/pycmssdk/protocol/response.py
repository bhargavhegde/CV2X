# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

import ctypes
from dataclasses import dataclass
from typing import Any, Generic, Optional, Type, TypeVar

from pycmssdk.protocol.header import ApiWireHeader
from pycmssdk.typing import CodecStructure

DataT = TypeVar('DataT')
PayloadT = TypeVar('PayloadT')


class ApiCallFailed(BaseException):
    """
    Exception raised for errors responded from the EAS

    Attributes:
        code: result code of the API command
    """

    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class Response(Generic[DataT, PayloadT]):
    data: DataT
    payload: PayloadT


def create_response(
    response_bytes: bytes, out_type: Optional[Type[CodecStructure]], has_out_buffer: bool
) -> Response[Optional[Any], Optional[bytes]]:
    data = None
    payload = None
    header = ApiWireHeader.from_buffer_copy(response_bytes)
    offset = ctypes.sizeof(header)
    if not header.is_result:
        raise ValueError('Response is malformed, no result flag presents')
    if header.result_code != 0:
        raise ApiCallFailed(header.result_code, f'Request was not successful, result code: {header.result_code}')
    if header.expect_result_data:
        if out_type is None:
            raise ValueError('Request expects output data, but output type is None')
        data_length = int.from_bytes(response_bytes[offset : offset + 2], 'little')
        if data_length != ctypes.sizeof(out_type):
            raise ValueError(
                f'Length in payload ({data_length} bytes) and length of '
                f'data ({ctypes.sizeof(out_type)} bytes) is not equal'
            )
        offset += 2
        data = out_type.from_buffer_copy(response_bytes, offset).encode()
        offset += data_length
    if header.expect_result_buffer:
        if not has_out_buffer:
            raise ValueError('Request expects output buffer, but output buffer param flag is False')
        buffer_length = int.from_bytes(response_bytes[offset : offset + 2], 'little')
        offset += 2
        remaining = len(response_bytes) - offset
        if buffer_length != remaining:
            raise ValueError(
                f'Buffer size in payload ({buffer_length} bytes) '
                f'is not equal with the size of the buffer ({remaining} bytes)'
            )
        payload = response_bytes[offset : offset + buffer_length]
    return Response(data, payload)
