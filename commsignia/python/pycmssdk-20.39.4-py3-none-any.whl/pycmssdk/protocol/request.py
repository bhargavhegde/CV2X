# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

import ctypes
from typing import Any, Optional, Type

from pycmssdk.protocol.header import ApiWireHeader
from pycmssdk.typing import CodecStructure


def create_request(
    header: ApiWireHeader, data: Optional[Any], in_type: Optional[Type[CodecStructure]], buffer: Optional[bytes]
) -> bytes:
    bytes_to_send = bytearray(header)
    if header.has_sent_data:
        if data is None or in_type is None:
            raise ValueError('HAS_SENT_DATA flag is enabled, no data or data type presents')
        bytes_to_send.extend(ctypes.sizeof(in_type).to_bytes(2, 'little'))
        bytes_to_send.extend(bytes(in_type.decode(data)))  # type: ignore[call-overload]
    if header.has_sent_buffer:
        if buffer is None:
            raise ValueError('HAS_SENT_BUFFER flag is enabled, no buffer presents')
        bytes_to_send.extend(len(buffer).to_bytes(2, 'little'))
        bytes_to_send.extend(buffer)
    return bytes(bytes_to_send)
