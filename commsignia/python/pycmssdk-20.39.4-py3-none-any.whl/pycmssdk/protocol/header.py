# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

from __future__ import annotations

import ctypes
from enum import IntEnum
from typing import Iterable, List, Optional, Type

from pycmssdk.typing import Codec
from pycmssdk.version import MAJOR_VERSION, MINOR_VERSION


class CmdModeFlag(IntEnum):
    HAS_SENT_DATA = 0
    HAS_SENT_BUFFER = 1
    EXPECT_RESULT_DATA = 2
    EXPECT_RESULT_BUFFER = 3
    NONBLOCKING = 4
    RESULT = 8


class ApiWireHeader(ctypes.Structure):
    """
    Represents the wire protocol header.
    Attributes:
        major_version: API major version
        minor_version: API minor version
        cmd_group: service group where the command belongs to
        cmd_code: command's service code
        cmd_mode: describes what kind of inputs and outputs the command has
        payload_size: size of the payload in bytes
        result_code: result of a requests, only has meaning in responses
    """

    _pack_ = 1

    _fields_ = [
        ('major_version', ctypes.c_uint8),
        ('minor_version', ctypes.c_uint8),
        ('reserved_1', ctypes.c_uint16),
        ('cmd_group', ctypes.c_uint16),
        ('cmd_code', ctypes.c_uint16),
        ('cmd_mode', ctypes.c_uint16),
        ('payload_size', ctypes.c_uint16),
        ('reserved_2', ctypes.c_uint32),
        ('result_code', ctypes.c_uint32),
    ]

    def __len__(self) -> int:
        """
        Gives back the length of the header

        Returns:
            Length of the header
        """
        return ctypes.sizeof(self)

    @property
    def has_sent_data(self) -> bool:
        return self._has_flag(CmdModeFlag.HAS_SENT_DATA)

    @property
    def has_sent_buffer(self) -> bool:
        return self._has_flag(CmdModeFlag.HAS_SENT_BUFFER)

    @property
    def expect_result_data(self) -> bool:
        return self._has_flag(CmdModeFlag.EXPECT_RESULT_DATA)

    @property
    def expect_result_buffer(self) -> bool:
        return self._has_flag(CmdModeFlag.EXPECT_RESULT_BUFFER)

    @property
    def is_nonblocking(self) -> bool:
        return self._has_flag(CmdModeFlag.NONBLOCKING)

    @property
    def is_result(self) -> bool:
        return self._has_flag(CmdModeFlag.RESULT)

    def _has_flag(self, flag: CmdModeFlag) -> bool:
        # pylint: disable=no-member
        return bool((self.cmd_mode >> flag) & 1)


def create_cmd_mode_flag_list(
    in_type: Optional[Type[Codec]],
    in_buffer: Optional[bytes],
    out_type: Optional[Type[Codec]],
    has_out_buffer: bool,
) -> Iterable[CmdModeFlag]:
    flags: List[CmdModeFlag] = []
    if in_type is not None:
        flags.append(CmdModeFlag.HAS_SENT_DATA)
    if in_buffer is not None:
        flags.append(CmdModeFlag.HAS_SENT_BUFFER)
    if out_type is not None:
        flags.append(CmdModeFlag.EXPECT_RESULT_DATA)
    if has_out_buffer:
        flags.append(CmdModeFlag.EXPECT_RESULT_BUFFER)
    return flags


def _compute_int_value_from_cmd_mode_flags(flags: Iterable[CmdModeFlag]) -> int:
    mode = 0
    for flag in flags:
        mode |= 1 << flag
    return mode


def create_api_wire_header(group: int, code: int, flags: Iterable[CmdModeFlag], payload_size: int) -> ApiWireHeader:
    header = ApiWireHeader()
    header.major_version = MAJOR_VERSION  # pylint: disable=attribute-defined-outside-init
    header.minor_version = MINOR_VERSION  # pylint: disable=attribute-defined-outside-init
    header.cmd_group = group  # pylint: disable=attribute-defined-outside-init
    header.cmd_code = code  # pylint: disable=attribute-defined-outside-init
    header.cmd_mode = _compute_int_value_from_cmd_mode_flags(flags)  # pylint: disable=attribute-defined-outside-init
    header.payload_size = payload_size  # pylint: disable=attribute-defined-outside-init
    return header
