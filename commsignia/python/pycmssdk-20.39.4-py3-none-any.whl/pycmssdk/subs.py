# Copyright Commsignia Ltd., 2021, All Rights Reserved.
# Unauthorised copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential.

from __future__ import annotations

import concurrent.futures
import ctypes
import threading
from abc import ABC, abstractmethod
from types import TracebackType
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Type, Union

from .log import get_logger
from .protocol import ApiWireHeader
from .typedef.internal._subs_types import _SubsNotifHandle

CallbackT = Union[Callable[[Any], None], Callable[[int, Any, Optional[bytes]], None], Callable[[int, Any], None]]

WILDCARD = 0


class SubscriptionHandle:
    """
    Contains information about a client subscription.
    Note:
        The callback will be called only if the service_code and the subscription_key match in the notification
        data received from the server.
        There is a WILDCARD subscription key, this won't filter the incoming notifications.
    Attributes:
        notify_code: the service_code has to match to get a notification from the server
        key: the subscription_key has to match to get a notification from the server
        callback: the callback to call if a proper notification is received
    """

    def __init__(
        self,
        notify_code: int,
        key: int,
        callback: CallbackT,
        unsubscribe_function: Callable[[SubscriptionHandle], None],
    ):
        self.notify_code = notify_code
        self.key = key
        self.callback = callback
        self._unsubscribe = unsubscribe_function

    def __enter__(self) -> SubscriptionHandle:
        return self

    def __exit__(
        self, exc_type: Optional[Type[BaseException]], exc_val: Optional[BaseException], exc_tb: Optional[TracebackType]
    ) -> None:
        self.unsubscribe()

    def unsubscribe(self) -> None:
        self._unsubscribe(self)


class SubscriptionHandler(ABC):
    """Base class for special module subscription handlers."""

    def __init__(self, thread_pool: concurrent.futures.ThreadPoolExecutor):
        self._thread_pool = thread_pool
        self._logger = get_logger('.'.join([__name__, self.__class__.__name__]))

    @property
    @abstractmethod
    def service_code(self) -> int:
        """Read only field for the given service's code"""

    @abstractmethod
    def handle(
        self, subscription_key: int, callbacks: Iterable[CallbackT], data_bytes: bytes, buffer: Optional[bytes] = None
    ) -> None:
        """This function parses the notification and calls all the callbacks with the proper parameters"""

    def _forward_callback(self, callback: CallbackT, *args: Any) -> None:
        future = self._thread_pool.submit(callback, *args)
        future.add_done_callback(self._callback_finished)

    def _callback_finished(self, future: concurrent.futures.Future) -> None:
        try:
            future.result()
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Exception while calling callback')


class SubscriptionDispatcher:
    """Registers, deregisters subscriptions and handles incoming notifications."""

    def __init__(self, handlers: Dict[int, SubscriptionHandler]):
        """
        Initialize the handlers, and the structures belonging to them.
        Args:
            handlers: dictionary for all the concrete SubscriptionHandler class with the service_code as key
        """
        self._logger = get_logger('.'.join([__name__, self.__class__.__name__]))
        self._handlers: Dict[int, SubscriptionHandler] = handlers
        self._handles_lock = threading.Lock()
        self._handles: List[SubscriptionHandle] = []

    def register(self, handle: SubscriptionHandle) -> None:
        """
        Subscribe to the given service.
        Args:
            handle: structure represents a client subscription
        Returns:
            A handle, that the caller can unsubscribe with.
        """
        with self._handles_lock:
            self._handles.append(handle)
        self._logger.debug('Subscription with code: %d', handle.notify_code)

    def deregister(self, handle: SubscriptionHandle) -> None:
        """
        Unsubscribe from the given service.
        Args:
            handle: subscription to unsubscribe
        """
        with self._handles_lock:
            self._handles.remove(handle)
        self._logger.debug('Unsubscribed with code: %d', handle.notify_code)

    def handle(self, notification: bytes) -> None:
        """
        Parses the notification and dispatch it to the proper subscribed clients.
        Args:
            notification: notification bytes without the frame
        Raises:
            ValueError: if the header is not correct
        """
        header = ApiWireHeader.from_buffer_copy(notification)
        offset = len(header)
        payload_len = len(notification) - len(header)
        if header.payload_size != payload_len:
            raise ValueError(
                f'Header payload size ({header.payload_size} bytes) and size of payload '
                f'({payload_len} bytes) does not match'
            )
        data_length = int.from_bytes(notification[offset : offset + 2], 'little')
        offset += 2
        subs_notif_handle = _SubsNotifHandle.from_buffer_copy(notification, offset).encode()
        offset += ctypes.sizeof(_SubsNotifHandle)
        data_bytes = notification[offset : offset + data_length - ctypes.sizeof(_SubsNotifHandle)]
        offset += data_length - ctypes.sizeof(_SubsNotifHandle)
        buffer = None
        if len(notification) > offset:
            buffer_length = int.from_bytes(notification[offset : offset + 2], 'little')
            offset += 2
            buffer = notification[offset : offset + buffer_length]
        service_code = header.cmd_code
        callbacks = self._filter_callbacks(service_code, subs_notif_handle.key)
        self._handlers[service_code].handle(subs_notif_handle.key, callbacks, data_bytes, buffer)

    def _filter_callbacks(self, service_code: int, subscription_key: int) -> Iterator[CallbackT]:
        with self._handles_lock:
            for handle in self._handles:
                good_service_code = handle.notify_code == service_code
                good_subs_key = handle.key in (WILDCARD, subscription_key)
                if good_service_code and good_subs_key:
                    yield handle.callback
